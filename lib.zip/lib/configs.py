configs = {"output_path": "./Outputs/", "BETA": 1}

